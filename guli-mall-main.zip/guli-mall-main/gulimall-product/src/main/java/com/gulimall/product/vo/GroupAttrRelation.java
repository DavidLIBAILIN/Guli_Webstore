package com.gulimall.product.vo;

import lombok.Data;

@Data
public class GroupAttrRelation {
    Long attrId;
    Long attrGroupId;
}
