package com.gulimall.product.vo;

import lombok.Data;

@Data
public class BrandResp {
    Long brandId;
    String brandName;
}
